## Test Code for PA1

This repository contains some JUnit 4 tests for PA1 ArrayIterator.

You need JUnit 4 libraries to run the tests. 

There is also test code for CSVReader.  If you do that assignment, then please contact instructor.

Please don't commit the test classes to Git or push them to Github.
